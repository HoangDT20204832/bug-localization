Contributing to Platform UI
===================

Contributions to the Eclipse platform are most welcome. There are many ways to contribute, 
from entering high quality bug reports, to contributing code or documentation changes. 
For a complete guide, see the [How to Contribute] [1] page on the team wiki.

[1]: http://wiki.eclipse.org/Platform_UI/How_to_Contribute